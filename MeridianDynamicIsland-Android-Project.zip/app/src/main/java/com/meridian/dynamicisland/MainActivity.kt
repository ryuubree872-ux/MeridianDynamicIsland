package com.meridian.dynamicisland

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.view.ViewGroup

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("island", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 11, 16)
        window.navigationBarColor = Color.rgb(8, 11, 16)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 34, 24, 24)
            setBackgroundColor(Color.rgb(8, 11, 16))
        }
        fun text(value: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
            TextView(this).apply {
                text = value; textSize = size; setTextColor(color)
                if (bold) setTypeface(null, Typeface.BOLD)
                setPadding(0, 8, 0, 8)
            }

        page.addView(text("MERIDIAN", 13f, 0xFF78DDF4.toInt(), true))
        page.addView(text("Dynamic Island", 30f, Color.WHITE, true))
        page.addView(text("Astronaut companion • Android overlay", 14f, 0xFF9AA7B5.toInt()))
        page.addView(text("Aktifkan izin tampil di atas aplikasi lain, lalu nyalakan Island.", 14f, 0xFFD2DAE3.toInt()))

        val permission = Button(this).apply {
            text = "IZINKAN OVERLAY"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }
        }
        page.addView(permission, matchWrap())

        val robot = makeSwitch("Tampilkan robot astronot", "showRobot", true)
        val clock = makeSwitch("Tampilkan jam", "showClock", true)
        val battery = makeSwitch("Tampilkan baterai", "showBattery", true)
        page.addView(robot); page.addView(clock); page.addView(battery)

        val start = Button(this).apply {
            text = "NYALAKAN DYNAMIC ISLAND"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    val i = Intent(this@MainActivity, IslandService::class.java).setAction(IslandService.ACTION_START)
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                }
            }
        }
        page.addView(start, matchWrap())

        val stop = Button(this).apply {
            text = "MATIKAN OVERLAY"
            setOnClickListener { stopService(Intent(this@MainActivity, IslandService::class.java)) }
        }
        page.addView(stop, matchWrap())
        page.addView(text("Catatan: overlay bekerja di atas launcher dan aplikasi lain setelah izin diberikan. Fitur musik/notification listener belum diaktifkan pada versi dasar ini.", 12f, 0xFF8492A3.toInt()))
        setContentView(page)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = 12 }

    private fun makeSwitch(label: String, key: String, default: Boolean): Switch {
        return Switch(this).apply {
            text = label
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean(key, default)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(key, checked).apply()
                sendBroadcast(Intent(IslandService.ACTION_REFRESH).setPackage(packageName))
            }
            setPadding(0, 12, 0, 12)
        }
    }
}
