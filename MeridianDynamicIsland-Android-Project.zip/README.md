# Meridian Dynamic Island (Android)

Starter project native Android/Kotlin untuk floating overlay bergaya Dynamic Island.

## Cara menjalankan
1. Buka folder ini melalui Android Studio.
2. Sync Gradle, lalu Build > Build APK(s).
3. Install APK pada perangkat Android.
4. Buka Meridian Island dan tekan **IZINKAN OVERLAY**.
5. Kembali ke aplikasi, tekan **NYALAKAN DYNAMIC ISLAND**.
6. Jika Android meminta izin notifikasi, izinkan agar notifikasi layanan terlihat.

## Yang sudah ada
- Overlay `TYPE_APPLICATION_OVERLAY` di atas launcher/aplikasi lain.
- Layanan foreground agar overlay tetap berjalan saat aplikasi utama ditutup.
- Robot astronot chibi bergaya 3D yang digambar dengan Android Canvas.
- Jam, indikator baterai, tap untuk expand/collapse.
- Pengaturan untuk menampilkan/menyembunyikan robot, jam, dan baterai.

## Batasan versi starter
- Belum membaca notifikasi aplikasi lain.
- Tombol musik/next/play belum dihubungkan ke sesi media Android.
- Mode pesawat/Wi-Fi/Bluetooth belum dikontrol (Android membatasi perubahan pengaturan sistem oleh aplikasi biasa).
- Sebagian vendor Android dapat menghentikan layanan di latar belakang; izinkan auto-start/background activity jika tersedia.
- Android 13+ memerlukan izin overlay dari Settings. Android 14+ menerapkan aturan foreground service khusus; deklarasi `specialUse` di sini untuk fungsi overlay yang dimulai pengguna. Distribusi Play Store memerlukan peninjauan kebijakan tambahan.

## Catatan build
Project menggunakan Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compileSdk 35, minSdk 26.
