package com.meridian.dynamicisland

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager

class IslandService : Service() {
    companion object {
        const val ACTION_START = "com.meridian.dynamicisland.START"
        const val ACTION_REFRESH = "com.meridian.dynamicisland.REFRESH"
        private const val CHANNEL = "meridian_island"
        private const val NOTIFICATION_ID = 41
    }

    private lateinit var wm: WindowManager
    private var island: IslandView? = null
    private val refreshReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { island?.invalidate() }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        registerReceiver(refreshReceiver, IntentFilter(ACTION_REFRESH), RECEIVER_NOT_EXPORTED)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, buildNotification())
        } else {
            startForeground(NOTIFICATION_ID, buildNotification())
        }
        if (island == null) showIsland()
        return START_STICKY
    }

    private fun showIsland() {
        island = IslandView(this)
        val params = WindowManager.LayoutParams(
            dp(190), dp(54),
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(8)
        }
        try { wm.addView(island, params) } catch (_: Exception) { island = null; stopSelf() }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setContentTitle("Meridian Island aktif")
            .setContentText("Astronaut overlay sedang berjalan")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true).build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Meridian Island", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        try { unregisterReceiver(refreshReceiver) } catch (_: Exception) {}
        island?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        island = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
