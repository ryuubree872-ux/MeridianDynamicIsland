package com.meridian.dynamicisland

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import android.content.Intent
import android.os.BatteryManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min

class IslandView(context: Context) : View(context) {
    private val prefs = context.getSharedPreferences("island", Context.MODE_PRIVATE)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var expanded = false
    private var lastTap = 0L

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        val w = width.toFloat(); val h = height.toFloat()
        val bg = RectF(0f, 0f, w, h)
        paint.shader = LinearGradient(0f, 0f, w, h, intArrayOf(0xFF090D14.toInt(), 0xFF020305.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(bg, h / 2, h / 2, paint)
        paint.shader = null
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 1f * d
        paint.color = 0xFF263544.toInt()
        canvas.drawRoundRect(bg, h / 2, h / 2, paint)
        paint.style = Paint.Style.FILL

        val showRobot = prefs.getBoolean("showRobot", true)
        val showClock = prefs.getBoolean("showClock", true)
        val showBattery = prefs.getBoolean("showBattery", true)
        if (showRobot) drawAstronaut(canvas, 27f*d, h/2, 0.82f*d)

        if (showClock) {
            paint.color = Color.WHITE; paint.textSize = 12f*d; paint.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            canvas.drawText(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()), 59f*d, h/2 + 4f*d, paint)
        }
        if (showBattery) {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100)
            val x = w - 34f*d; val y = h/2
            paint.color = 0xFF9DEBFA.toInt()
            canvas.drawRoundRect(x, y-5f*d, x+17f*d, y+5f*d, 2f*d, 2f*d, paint)
            paint.color = 0xFF0B1118.toInt()
            canvas.drawRoundRect(x+2f*d, y-3f*d, x+2f*d+13f*d*level/100f, y+3f*d, 1f*d, 1f*d, paint)
            paint.color = 0xFF9DEBFA.toInt()
            canvas.drawRect(x+17f*d, y-2f*d, x+19f*d, y+2f*d, paint)
        }
        if (expanded) {
            paint.color = 0xFFB9EAF5.toInt(); paint.textSize = 10f*d
            canvas.drawText("MERIDIAN  •  TAP UNTUK TUTUP", 59f*d, h-8f*d, paint)
        }
        postInvalidateDelayed(1000)
    }

    private fun drawAstronaut(c: Canvas, cx: Float, cy: Float, s: Float) {
        // Soft 3D-style chibi helmet and reflective visor, drawn natively (no image asset).
        paint.shader = RadialGradient(cx-4*s, cy-7*s, 25*s,
            intArrayOf(0xFFFFFFFF.toInt(), 0xFFB8D5E4.toInt(), 0xFF617E91.toInt()),
            null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, 21*s, paint); paint.shader = null
        paint.color = 0xFF23394A.toInt(); c.drawCircle(cx, cy+1*s, 15*s, paint)
        paint.shader = LinearGradient(cx-10*s, cy-11*s, cx+10*s, cy+11*s,
            intArrayOf(0xFF102A40.toInt(), 0xFF06111D.toInt()), null, Shader.TileMode.CLAMP)
        c.drawRoundRect(cx-14*s, cy-11*s, cx+14*s, cy+11*s, 10*s, 10*s, paint); paint.shader = null
        paint.color = 0xFF80E8FF.toInt()
        c.drawOval(cx-8*s, cy-2*s, cx-3*s, cy+3*s, paint)
        c.drawOval(cx+3*s, cy-2*s, cx+8*s, cy+3*s, paint)
        paint.color = 0xFFB7F5FF.toInt()
        c.drawCircle(cx-9*s, cy-12*s, 2.5f*s, paint)
        paint.color = 0xFFDFEDF4.toInt()
        c.drawRoundRect(cx-10*s, cy+16*s, cx+10*s, cy+21*s, 4*s, 4*s, paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            expanded = !expanded
            val p = layoutParams
            p.width = (if (expanded) 260 else 190) * resources.displayMetrics.density.toInt()
            layoutParams = p
            invalidate()
            return true
        }
        return true
    }
}
